package com.login;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class LoginController {
	
	@RequestMapping(value="/home")
	public String loginForm() {
		return "home";
	}

	@RequestMapping(value="/login")
	public String login() {
			return "login";
	}

	@RequestMapping(value="/loout")
	public void logout() {
		
	}
}
