package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {

	@RequestMapping("/xxx")
	public String aaa(){
		System.out.println("aaa");	
		return "/WEB-INF/views/home.jsp";
	}
	@RequestMapping("/yyy")
    public String bbb(){
		System.out.println("bbb");
		return "/WEB-INF/views/home.jsp";
	}
}
